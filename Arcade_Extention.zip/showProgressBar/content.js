const currentUrl = window.location.pathname;

// Disable the script if "/leaderboard" is part of the URL
if (currentUrl.includes('/leaderboard')) {
    console.log('Extension disabled on leaderboard page.');
} else {
    const assessmentElement = document.querySelector('.lab-assessment__tab.js-open-lab-assessment-panel');
    const leaderboardElement = document.querySelector('ql-leaderboard-container');
    const assessmentPanel = document.querySelector('.lab-assessment__panel.js-lab-assessment-panel');
    const accountSectionScroll = document.querySelector('.control-panel-section');

    if (assessmentElement) assessmentElement.style.display = 'block';
    else console.log('Assessment element not found.');
    if (leaderboardElement) leaderboardElement.style.display = 'none';
    else console.log('Leaderboard element not found.');
    if (assessmentPanel) assessmentPanel.style.display = 'block';
    else console.log('Assessment panel not found.');

    // scroll
    // make the overflow y of accountSectionScroll to be hidden
    if (accountSectionScroll) accountSectionScroll.style.overflowY = 'hidden';
    else console.log('Failed to prevent overflow in Y');
}
